<?php
session_start();

$host = "localhost";
$user = "root";
$pass = "";
$db   = "uas_wulan";

// PERBAIKAN: Gunakan mysqli_connect, bukan mysqli_query
$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>