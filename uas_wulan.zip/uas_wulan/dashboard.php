<?php 
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$uid = $_SESSION['user_id'];
$role = $_SESSION['role'];

// --- PROSES SIMPAN PEMBAYARAN (MAHASISWA) ---
if ($role == 'mahasiswa' && isset($_POST['bayar'])) {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $metode = $_POST['metode'];
    $jumlah = $_POST['jumlah'];
    $kode = $_POST['kode_bayar'];
    
    $bukti = time() . "_" . $_FILES['bukti']['name'];
    if (!is_dir('uploads')) mkdir('uploads');
    if (move_uploaded_file($_FILES['bukti']['tmp_name'], "uploads/".$bukti)) {
        mysqli_query($conn, "INSERT INTO pembayaran (mahasiswa_id, nim, nama_lengkap, metode, kode_bayar, jumlah, bukti_bayar) 
                             VALUES ('$uid', '$nim', '$nama', '$metode', '$kode', '$jumlah', '$bukti')");
        echo "<script>alert('Pembayaran Berhasil Dikirim!'); window.location='dashboard.php';</script>";
    }
}

// --- PROSES APPROVE (ADMIN) ---
if ($role == 'admin' && isset($_GET['approve'])) {
    $id_bayar = $_GET['approve'];
    mysqli_query($conn, "UPDATE pembayaran SET status='lunas' WHERE id='$id_bayar'");
    header("Location: dashboard.php");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Smart Dashboard | uas_wulan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="p-4 md:p-10">

    <div class="max-w-7xl mx-auto">
        <header class="glass-card p-6 mb-8 flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-black italic tracking-tighter uppercase"><?= $role ?>.SYSTEM.👋</h1>
                <p class="text-[10px] uppercase tracking-[0.2em] text-white/50">Project uas_wulan 2026</p>
            </div>
            <a href="logout.php" class="bg-red-500/20 hover:bg-red-500 text-red-500 hover:text-white px-4 py-2 rounded-lg font-bold text-[10px] transition-all border border-red-500/50 shadow-lg">LOGOUT</a>
        </header>

        <?php if ($role == 'mahasiswa'): ?>
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            <div class="lg:col-span-7 glass-card p-8">
                <h2 class="text-xl font-black mb-6 border-l-4 border-indigo-500 pl-4 uppercase">Input Pembayaran</h2>
                <form method="POST" enctype="multipart/form-data" class="space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <input type="text" name="nim" id="m_nim" oninput="updateSmartQR()" placeholder="NIM" class="w-full" required>
                        <input type="text" name="nama" id="m_nama" oninput="updateSmartQR()" placeholder="Nama Lengkap" class="w-full" required>
                    </div>
                    
                    <input type="number" id="m_harga" name="jumlah" oninput="updateSmartQR()" placeholder="Nominal Rp" class="w-full font-bold text-indigo-400 text-xl" required>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <select name="metode" id="m_metode" onchange="updateSmartQR(); toggleMetode();" class="w-full">
                            <option value="QRIS">QRIS / Barcode</option>
                            <option value="TRANSFER BANK">Transfer Bank</option>
                            <option value="E-WALLET">DANA / GOPAY</option>
                        </select>
                        <input type="text" name="kode_bayar" placeholder="ID Transaksi / Ref" class="w-full border-dashed" required>
                    </div>

                    <div id="bank_info" class="hidden p-4 bg-white/5 border border-white/10 rounded-xl text-xs text-indigo-300 italic">
                        * Transfer ke: MANDIRI 123-000-4455 a/n UAS WULAN
                    </div>

                    <div class="p-4 bg-white/5 rounded-xl border border-white/10">
                        <p class="text-[9px] mb-2 uppercase opacity-50 font-bold">Upload Bukti</p>
                        <input type="file" name="bukti" class="w-full text-xs" required>
                    </div>
                    
                    <button type="submit" name="bayar" class="btn-primary w-full py-4 rounded-xl font-black tracking-widest">KIRIM PEMBAYARAN</button>
                </form>
            </div>

            <div class="lg:col-span-5 flex flex-col items-center">
                <div class="qris-stand w-full max-w-[320px] text-center text-black relative shadow-2xl">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/a/a2/Logo_QRIS.svg" class="h-8 mx-auto mb-4">
                    <div class="relative bg-gray-100 p-4 rounded-xl mb-4 border-2 border-gray-200">
                        <div id="laser" class="scan-line hidden"></div>
                        <img id="qr_img" src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=SILAKAN_ISI_DATA" class="w-full rounded-lg">
                    </div>
                    <div id="qr_data_preview" class="hidden text-[10px] font-bold bg-gray-800 text-white p-3 rounded-lg mb-3 text-left">
                        <p id="p_nama"></p>
                        <p id="p_nim"></p>
                        <p id="p_nominal" class="text-green-400 text-sm"></p>
                    </div>
                    <p class="text-[8px] text-gray-500 uppercase font-bold tracking-widest">Scan QR untuk melihat rincian</p>
                </div>
            </div>
        </div>

        <?php else: ?>
        <div class="glass-card p-8">
            <div class="flex justify-between items-center mb-6 border-l-4 border-green-500 pl-4">
                <h2 class="text-xl font-black uppercase text-green-400">Monitoring & Verifikasi Pembayaran.👋</h2>
                <div class="flex gap-4 text-[10px] font-bold">
                    <span class="flex items-center gap-1"><div class="w-2 h-2 bg-green-500 rounded-full"></div> LUNAS</span>
                    <span class="flex items-center gap-1"><div class="w-2 h-2 bg-yellow-500 rounded-full"></div> PENDING</span>
                    <span class="flex items-center gap-1"><div class="w-2 h-2 bg-red-500 rounded-full"></div> BELUM BAYAR</span>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="opacity-40 text-[9px] uppercase tracking-[0.3em] border-b border-white/10">
                        <tr>
                            <th class="p-4">Mahasiswa (NIM)</th>
                            <th class="p-4 text-center">Metode</th>
                            <th class="p-4 text-right">Nominal</th>
                            <th class="p-4 text-center">Tgl Bayar</th>
                            <th class="p-4 text-center">Bukti</th>
                            <th class="p-4 text-center">Status</th>
                            <th class="p-4 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm">
                        <?php 
                        // Query sakti: Mengambil semua user mhs dan status bayar terakhirnya
                        $sql = "SELECT users.username, users.id as uid, pembayaran.* FROM users 
                                LEFT JOIN pembayaran ON users.id = pembayaran.mahasiswa_id 
                                WHERE users.role = 'mahasiswa' 
                                ORDER BY pembayaran.status ASC, users.username ASC";
                        
                        $res = mysqli_query($conn, $sql);
                        while($r = mysqli_fetch_assoc($res)): 
                            $status_class = "bg-red-500/20 text-red-500 border border-red-500/50";
                            $status_text = "BELUM BAYAR";
                            
                            if($r['status'] == 'pending') {
                                $status_class = "bg-yellow-500 text-black";
                                $status_text = "PENDING";
                            } elseif($r['status'] == 'lunas') {
                                $status_class = "bg-green-500 text-white";
                                $status_text = "LUNAS.✅";
                            }
                        ?>
                        <tr class="border-b border-white/5 hover:bg-white/5 transition">
                            <td class="p-4">
                                <span class="font-bold text-white"><?= strtoupper($r['username']) ?></span><br>
                                <span class="text-[10px] opacity-40"><?= $r['nim'] ?? 'N/A' ?></span>
                            </td>
                            <td class="p-4 text-center text-[10px] italic">
                                <?= $r['metode'] ? '<span class="text-indigo-400">'.$r['metode'].'</span>' : '-' ?>
                            </td>
                            <td class="p-4 text-right font-black">
                                <?= $r['jumlah'] ? 'Rp '.number_format($r['jumlah']) : '-' ?>
                            </td>
                            <td class="p-4 text-center text-[10px] opacity-40">
                                <?= $r['tanggal_bayar'] ? date('d/m/y H:i', strtotime($r['tanggal_bayar'])) : '-' ?>
                            </td>
                            <td class="p-4 text-center">
                                <?php if($r['bukti_bayar']): ?>
                                    <a href="uploads/<?= $r['bukti_bayar'] ?>" target="_blank" class="text-[9px] bg-white/10 px-2 py-1 rounded hover:bg-white/20 transition">VIEW</a>
                                <?php else: ?>
                                    <span class="opacity-20">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-4 text-center">
                                <span class="px-2 py-1 rounded-[4px] text-[8px] font-black <?= $status_class ?>">
                                    <?= $status_text ?>
                                </span>
                            </td>
                            <td class="p-4 text-center">
                                <?php if($r['status'] == 'pending'): ?>
                                    <a href="?approve=<?= $r['id'] ?>" class="bg-indigo-600 px-4 py-2 rounded-lg text-[10px] font-bold hover:bg-indigo-500 transition">APPROVE</a>
                                <?php elseif(!$r['status']): ?>
                                    <span class="text-[9px] opacity-30 italic">No Data</span>
                                <?php else: ?>
                                    <span class="text-green-500 text-[10px] font-black italic text-center">VERIFIED</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

    </div>

    <script>
        function updateSmartQR() {
            const nim = document.getElementById('m_nim').value;
            const nama = document.getElementById('m_nama').value;
            const harga = document.getElementById('m_harga').value;
            const metode = document.getElementById('m_metode').value;
            
            const img = document.getElementById('qr_img');
            const preview = document.getElementById('qr_data_preview');
            const lsr = document.getElementById('laser');

            if(nim && nama && harga > 0) {
                // DATA YANG AKAN MUNCUL SAAT DI SCAN:
                const qrContent = `DATA PEMBAYARAN UAS WULAN\n------------------\nNAMA: ${nama.toUpperCase()}\nNIM: ${nim}\nNOMINAL: Rp ${new Intl.NumberFormat('id-ID').format(harga)}\nMETODE: ${metode}\n------------------\nSTATUS: MENUNGGU KONFIRMASI`;
                
                img.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(qrContent)}`;
                
                // Tampilan Preview di Layar
                preview.classList.remove('hidden');
                lsr.classList.remove('hidden');
                document.getElementById('p_nama').innerText = "MHS: " + nama;
                document.getElementById('p_nim').innerText = "NIM: " + nim;
                document.getElementById('p_nominal').innerText = "TOTAL: Rp " + new Intl.NumberFormat('id-ID').format(harga);
            }
        }

        function toggleMetode() {
            const m = document.getElementById('m_metode').value;
            const bInfo = document.getElementById('bank_info');
            if(m !== 'QRIS') {
                bInfo.classList.remove('hidden');
            } else {
                bInfo.classList.add('hidden');
            }
        }
    </script>
</body>
</html>