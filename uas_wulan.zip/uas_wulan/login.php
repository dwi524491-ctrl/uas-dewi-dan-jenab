<?php 
include 'config.php';
if (isset($_POST['login'])) {
    $u = $_POST['user']; $p = $_POST['pass'];
    $res = mysqli_query($conn, "SELECT * FROM users WHERE username='$u'");
    $row = mysqli_fetch_assoc($res);
    if ($row && password_verify($p, $row['password'])) {
        $_SESSION['user_id'] = $row['id']; $_SESSION['role'] = $row['role'];
        header("Location: dashboard.php");
    } else { echo "<script>alert('Gagal!');</script>"; }
}
?>
<!DOCTYPE html>
<html>
<head><title>Login | uas_wulan</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="style.css"></head>
<body class="items-center justify-center p-6">
    <div class="glass-card p-10 w-full max-w-md text-center mx-auto mt-20">
        <h2 class="text-3xl font-black italic mb-6">LOGIN.👋</h2>
        <form method="POST" class="space-y-4">
            <input type="text" name="user" placeholder="Username" class="w-full" required>
            <input type="password" name="pass" placeholder="Password" class="w-full" required>
            <button type="submit" name="login" class="btn-primary w-full py-4 rounded-xl">MASUK</button>
        </form>
        <div class="mt-6 text-xs opacity-50"><a href="register.php">Daftar Akun</a> | <a href="lupa_sandi.php">Lupa Sandi</a></div>
    </div>
</body>
</html>