<?php 
include 'config.php';
if (isset($_POST['reset'])) {
    $u = $_POST['user']; $p = password_hash($_POST['new_pass'], PASSWORD_DEFAULT);
    mysqli_query($conn, "UPDATE users SET password='$p' WHERE username='$u'");
    echo "<script>alert('Berhasil!'); window.location='login.php';</script>";
}
?>
<!DOCTYPE html>
<html>
<head><title>Reset | uas_wulan</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="style.css"></head>
<body class="items-center justify-center p-6">
    <div class="glass-card p-10 w-full max-w-md mx-auto mt-20 text-center">
        <h2 class="text-3xl font-black italic mb-6">RESET.👋</h2>
        <form method="POST" class="space-y-4">
            <input type="text" name="user" placeholder="Username" class="w-full" required>
            <input type="password" name="new_pass" placeholder="Password Baru" class="w-full" required>
            <button type="submit" name="reset" class="btn-primary w-full py-4 rounded-xl">UPDATE</button>
        </form>
    </div>
</body>
</html>