<?php 
include 'config.php';
if (isset($_POST['register'])) {
    $username = $_POST['username'];
    // Gunakan password_hash agar aman
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    
    // Perbaikan query yang terpotong di gambar Anda
    mysqli_query($conn, "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')");
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register | uas_wulan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="flex items-center justify-center p-6">
    <div class="glass-card p-10 w-full max-w-md text-center">
        <h2 class="text-2xl font-black mb-6">REGISTRASI.👋</h2>
        <form method="POST" class="space-y-4">
            <input type="text" name="username" placeholder="Username" class="w-full" required>
            <input type="password" name="password" placeholder="Password" class="w-full" required>
            <select name="role" class="w-full">
                <option value="mahasiswa">Mahasiswa</option>
                <option value="admin">Admin</option>
            </select>
            <button type="submit" name="register" class="btn-primary w-full py-4 rounded-xl mt-4">DAFTAR</button>
        </form>
    </div>
</body>
</html>